## Running the file
The code was developed in the ‘Indeed-HackerRank.ipynb’ Jupiter notebook. To launch the file, make sure a Python package is installed and then type the following from the appropriate directory:

`jupiter notebook Indeed-HackerRank.ipynb`

You will need to have the ‘train.tsv’ and ‘test.tsv’ data files saved in the same working directory as the notebook.

You can work through the steps in the code by pressing the ‘play’ button. Once the final step executes, a ‘tags.tsv’ file will be written as output. 

One final step is needed before testing the output (I unfortunately ran out of time to automate this step): Open the ‘tags.tsv’ file in a text editor and do a ‘find-and-replace’, searching for all instances of ‘“”’ and replacing them with blanks (‘’). The ‘tags.tsv’ file is then ready for testing against the Indeed / HackerRank.com scoring system.